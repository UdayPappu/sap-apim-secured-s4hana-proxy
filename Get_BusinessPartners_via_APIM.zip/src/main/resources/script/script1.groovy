

import com.sap.gateway.ip.core.customdev.util.Message
import com.sap.it.api.ITApiFactory
import com.sap.it.api.securestore.SecureStoreService

def Message processData(Message message) {
    def store = ITApiFactory.getService(SecureStoreService.class, null)
    def cred = store.getUserCredential("APIM_APP_KEY")
    message.setHeader("APIKey", new String(cred.getPassword()))
    message.setHeader("Accept", "application/json")
    return message
}